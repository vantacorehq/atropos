#!/usr/bin/env python3
"""
ATROPOS — Autonomous agent for social chaos & arbitrage.
One file. Zero dependencies. It watches the panic. It cuts the noise.

Pipeline
    Source ──► Redactor/normalizer ──► Constraint-Forbid propagation ──► Signal builder
    (async)    (PII + secrets)         (bounds propagation to fixpoint)   (survivor sentiment)

Design notes
  * Stdlib only: asyncio, urllib, json, re, ast, ...
  * Rules are *data* (strings). They are parsed with `ast`, validated against a strict
    whitelist and compiled into closures. `eval`, `exec` and `compile` are never used.
  * Constraint protocol: every post owns a credibility interval [lo, hi] in [0, 1].
    Rules only ever *narrow* intervals (forbid -> [0,0], cap -> lower hi, floor -> raise lo),
    so propagation is monotone and terminates. Cross-post context (duplicate clusters,
    author history, cluster taint) is recomputed from the survivors each round, so
    pruning one post can cascade into pruning others.

Research tooling only. Nothing here is financial advice.
"""
from __future__ import annotations

import argparse
import ast
import asyncio
import datetime as _dt
import hashlib
import json
import logging
import math
import operator
import os
import random
import re
import secrets
import statistics
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib
from collections import Counter, defaultdict, deque
from dataclasses import asdict, dataclass, field
from typing import Any, AsyncIterator, Callable, Deque, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

__version__ = "0.1.0"
log = logging.getLogger("atropos")

# ════════════════════════════════════════════════════════════════════════════
# 1. PII / SECRET MASKING LAYER
# ════════════════════════════════════════════════════════════════════════════

_PII_PATTERNS: Tuple[Tuple[str, "re.Pattern[str]"], ...] = (
    ("JWT", re.compile(r"\beyJ[\w-]{8,}\.[\w-]{8,}\.[\w-]{8,}\b")),
    ("AWS_KEY", re.compile(r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b")),
    ("GH_TOKEN", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{20,}\b")),
    ("API_KEY", re.compile(r"\bsk-[A-Za-z0-9_-]{16,}\b")),
    ("BEARER", re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._~+/=-]{12,}")),
    ("EMAIL", re.compile(r"\b[\w.+-]+@[\w-]+(?:\.[\w-]+)+\b")),
    ("SSN", re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
    ("CARD", re.compile(r"\b(?:\d[ -]?){13,19}\b")),
    ("PHONE", re.compile(r"(?<!\w)(?:\+\d{8,15}|(?:\+\d{1,3}[ .-]?)?\(?\d{3}\)?[ .-]\d{3}[ .-]\d{4})(?!\w)")),
    ("IPV4", re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")),
)
_QUERY_SECRET = re.compile(
    r"(?i)([?&](?:access_token|token|api[_-]?key|key|secret|sig|signature|password)=)[^&#\s]+"
)


class Redactor:
    """Masks registered secrets (exact match) and generic PII/secret shapes (regex)."""

    def __init__(self) -> None:
        self._secrets: Dict[str, str] = {}

    def register(self, name: str, value: str) -> None:
        if value and len(value) >= 6:
            self._secrets[name] = value

    def mask(self, text: Any) -> str:
        if text is None:
            return ""
        text = str(text)
        for name, val in self._secrets.items():
            if val in text:
                text = text.replace(val, f"[SECRET:{name}]")
        text = _QUERY_SECRET.sub(r"\1[REDACTED]", text)
        for label, rx in _PII_PATTERNS:
            text = rx.sub(f"[{label}]", text)
        return text


class MaskingFilter(logging.Filter):
    """Logging filter: nothing sensitive reaches a handler, including exception text."""

    def __init__(self, redactor: Redactor) -> None:
        super().__init__()
        self._r = redactor

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            msg = record.getMessage()
        except Exception:  # malformed format args
            msg = str(record.msg)
        if record.exc_info:
            exc = record.exc_info[1]
            msg += f" | {type(exc).__name__}: {exc}"
            record.exc_info = None
            record.exc_text = None
        record.msg, record.args = self._r.mask(msg), ()
        return True


class SecretMissing(KeyError):
    pass


class Vault:
    """Holds tokens in memory. Callers reference them as {{secret:NAME}} placeholders."""

    _PH = re.compile(r"\{\{secret:([A-Za-z0-9_]+)\}\}")

    def __init__(self, redactor: Redactor, env_prefix: str = "ATROPOS_SECRET_") -> None:
        self._red = redactor
        self._store: Dict[str, str] = {}
        for key, val in os.environ.items():
            if key.startswith(env_prefix):
                self.put(key[len(env_prefix):], val)

    def put(self, name: str, value: str) -> None:
        self._store[name] = value
        self._red.register(name, value)

    def inject(self, template: str) -> str:
        def sub(m: "re.Match[str]") -> str:
            try:
                return self._store[m.group(1)]
            except KeyError:
                raise SecretMissing(f"secret '{m.group(1)}' is not registered") from None

        return self._PH.sub(sub, template)

    def __repr__(self) -> str:  # never print values
        return f"<Vault names={sorted(self._store)}>"


class TransportError(RuntimeError):
    pass


class SecureTransport:
    """
    stdlib HTTP client with secret injection at the last possible moment.
    Logs only the *template* form of URL/headers; errors are re-raised masked and
    with their original cause suppressed so unmasked text never leaks via tracebacks.
    """

    def __init__(self, vault: Vault, redactor: Redactor, *, allow_hosts: Optional[Sequence[str]] = None,
                 timeout: float = 10.0, max_bytes: int = 4_000_000, retries: int = 2) -> None:
        self.vault, self.red = vault, redactor
        self.allow_hosts = set(h.lower() for h in allow_hosts) if allow_hosts else None
        self.timeout, self.max_bytes, self.retries = timeout, max_bytes, retries

    async def request(self, method: str, url: str, headers: Optional[Mapping[str, str]] = None,
                      body: Optional[bytes] = None) -> bytes:
        return await asyncio.to_thread(self._blocking, method, url, dict(headers or {}), body)

    def _blocking(self, method: str, url: str, headers: Dict[str, str], body: Optional[bytes]) -> bytes:
        log.info("HTTP %s %s", method, self.red.mask(url))
        try:
            real_url = self.vault.inject(url)
            real_headers = {k: self.vault.inject(v) for k, v in headers.items()}
        except SecretMissing as exc:
            raise TransportError(str(exc)) from None
        parts = urllib.parse.urlsplit(real_url)
        if parts.scheme not in ("http", "https"):
            raise TransportError(f"scheme '{parts.scheme}' not allowed")
        if self.allow_hosts is not None and (parts.hostname or "").lower() not in self.allow_hosts:
            raise TransportError(f"host '{parts.hostname}' not in allowlist")
        real_headers.setdefault("User-Agent", f"atropos/{__version__}")
        last = "unknown error"
        for attempt in range(self.retries + 1):
            try:
                req = urllib.request.Request(real_url, data=body, headers=real_headers, method=method)
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    data = resp.read(self.max_bytes + 1)
                if len(data) > self.max_bytes:
                    raise TransportError("response exceeds max_bytes")
                return data
            except TransportError:
                raise
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                last = self.red.mask(f"{type(exc).__name__}: {exc}")
                time.sleep(min(2.0, 0.25 * 2 ** attempt))
        raise TransportError(last) from None


# ════════════════════════════════════════════════════════════════════════════
# 2. RESTRICTIVE EVALUATION ENGINE  (ast whitelist -> closures; no eval/exec)
# ════════════════════════════════════════════════════════════════════════════

class RuleError(ValueError):
    pass


def _div(a: float, b: float) -> float:
    return a / b if b else 0.0


def _floordiv(a: float, b: float) -> float:
    return a // b if b else 0.0


def _mod(a: float, b: float) -> float:
    return a % b if b else 0.0


def _pow(a: float, b: float) -> float:
    if abs(b) > 8 or abs(a) > 1e6:
        raise RuleError("pow out of bounds")
    try:
        r = a ** b
    except ZeroDivisionError:
        return 0.0
    return r if isinstance(r, (int, float)) else 0.0  # complex -> 0


_BINOPS: Dict[type, Callable[[Any, Any], Any]] = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.Div: _div, ast.FloorDiv: _floordiv, ast.Mod: _mod, ast.Pow: _pow,
}
_CMPOPS: Dict[type, Callable[[Any, Any], bool]] = {
    ast.Lt: operator.lt, ast.LtE: operator.le, ast.Gt: operator.gt,
    ast.GtE: operator.ge, ast.Eq: operator.eq, ast.NotEq: operator.ne,
}
_FUNCS: Dict[str, Tuple[Callable[..., float], int, int]] = {  # name: (fn, min_args, max_args)
    "min": (min, 2, 4), "max": (max, 2, 4), "abs": (abs, 1, 1),
    "log": (lambda x: math.log(max(x, 1e-12)), 1, 1),
    "sqrt": (lambda x: math.sqrt(max(x, 0.0)), 1, 1),
    "exp": (lambda x: math.exp(min(x, 50.0)), 1, 1),
    "tanh": (math.tanh, 1, 1),
    "clip": (lambda x, lo, hi: max(lo, min(hi, x)), 3, 3),
    "sign": (lambda x: (x > 0) - (x < 0), 1, 1),
}


class SafeExpr:
    """
    A restricted arithmetic/boolean expression.
    Allowed: numbers, booleans, declared variable names, + - * / // % ** (bounded),
    comparisons, and/or/not, ternary, and a fixed set of pure math functions.
    Everything else (attributes, subscripts, lambdas, comprehensions, strings, imports,
    keyword args, starred args, walrus, f-strings...) raises RuleError at *parse* time.
    """

    MAX_LEN, MAX_NODES, MAX_DEPTH = 400, 120, 16

    def __init__(self, source: str, variables: Iterable[str]) -> None:
        if not isinstance(source, str) or len(source) > self.MAX_LEN:
            raise RuleError("expression missing or too long")
        self.source = source.strip()
        self.variables = frozenset(variables)
        self.uses: set = set()
        self._nodes = 0
        try:
            tree = ast.parse(self.source, mode="eval")
        except SyntaxError as exc:
            raise RuleError(f"syntax error: {exc.msg}") from None
        self._fn = self._compile(tree.body, 0)

    def __call__(self, env: Mapping[str, float]) -> Any:
        return self._fn(env)

    def _compile(self, n: ast.AST, depth: int) -> Callable[[Mapping[str, float]], Any]:
        self._nodes += 1
        if self._nodes > self.MAX_NODES or depth > self.MAX_DEPTH:
            raise RuleError("expression too complex")
        t, d = type(n), depth + 1
        if t is ast.Constant:
            v = n.value  # type: ignore[attr-defined]
            if isinstance(v, (bool, int, float)):
                return lambda env: v
            raise RuleError(f"constant {v!r} not allowed")
        if t is ast.Name:
            name = n.id  # type: ignore[attr-defined]
            if name not in self.variables:
                raise RuleError(f"unknown name '{name}'")
            self.uses.add(name)
            return lambda env: env.get(name, 0.0)
        if t is ast.UnaryOp:
            f = self._compile(n.operand, d)  # type: ignore[attr-defined]
            op = type(n.op)  # type: ignore[attr-defined]
            if op is ast.Not:
                return lambda env: not f(env)
            if op is ast.USub:
                return lambda env: -f(env)
            if op is ast.UAdd:
                return lambda env: +f(env)
            raise RuleError("unary operator not allowed")
        if t is ast.BinOp:
            fn = _BINOPS.get(type(n.op))  # type: ignore[attr-defined]
            if fn is None:
                raise RuleError("binary operator not allowed")
            l, r = self._compile(n.left, d), self._compile(n.right, d)  # type: ignore[attr-defined]
            return lambda env: fn(l(env), r(env))
        if t is ast.BoolOp:
            parts = [self._compile(v, d) for v in n.values]  # type: ignore[attr-defined]
            if isinstance(n.op, ast.And):  # type: ignore[attr-defined]
                return lambda env: all(p(env) for p in parts)
            return lambda env: any(p(env) for p in parts)
        if t is ast.Compare:
            first = self._compile(n.left, d)  # type: ignore[attr-defined]
            chain = []
            for op, comp in zip(n.ops, n.comparators):  # type: ignore[attr-defined]
                fn = _CMPOPS.get(type(op))
                if fn is None:
                    raise RuleError("comparison operator not allowed")
                chain.append((fn, self._compile(comp, d)))

            def cmp(env: Mapping[str, float]) -> bool:
                left = first(env)
                for fn_, rf in chain:
                    right = rf(env)
                    if not fn_(left, right):
                        return False
                    left = right
                return True

            return cmp
        if t is ast.IfExp:
            c, a, b = (self._compile(x, d) for x in (n.test, n.body, n.orelse))  # type: ignore[attr-defined]
            return lambda env: a(env) if c(env) else b(env)
        if t is ast.Call:
            fname = getattr(n.func, "id", None)  # type: ignore[attr-defined]
            if not isinstance(n.func, ast.Name) or fname not in _FUNCS or n.keywords:  # type: ignore[attr-defined]
                raise RuleError("only plain calls to whitelisted functions are allowed")
            fn, lo, hi = _FUNCS[fname]
            if not lo <= len(n.args) <= hi:  # type: ignore[attr-defined]
                raise RuleError(f"{fname}() takes {lo}..{hi} arguments")
            args = [self._compile(a, d) for a in n.args]  # type: ignore[attr-defined]
            return lambda env: fn(*(a(env) for a in args))
        raise RuleError(f"{t.__name__} is not allowed")


# ════════════════════════════════════════════════════════════════════════════
# 3. DATA MODEL, FEATURES, SENTIMENT
# ════════════════════════════════════════════════════════════════════════════

BASE_VARS = frozenset({
    "followers", "account_age_days", "likes", "reposts", "replies", "engagement", "verified",
    "sentiment", "abs_sent", "shill_score", "url_count", "mention_count", "hashtag_count",
    "text_len", "caps_ratio",
})
CONTEXT_VARS = frozenset({
    "cluster_size", "dup_cluster", "dup_rank", "cluster_dead_frac", "author_posts", "author_dead",
})
SIGNAL_VARS = frozenset({
    "clean_net", "raw_net", "divergence", "mass", "noise_ratio", "momentum", "n_clean", "n_raw",
})

_URL = re.compile(r"https?://\S+|\b(?:t\.me|bit\.ly)/\S+", re.I)
_MENTION = re.compile(r"@\w+")
_TOPIC = re.compile(r"(?<![\w$])[$#][A-Za-z][A-Za-z0-9_]{1,9}\b")
_WORD = re.compile(r"[a-z0-9$']+")
_TOKEN = re.compile(r"[a-z']+|[\U0001F300-\U0001FAFF]")

_LEX: Dict[str, float] = {
    # positive
    "bullish": 2.5, "strong": 1.8, "good": 1.5, "great": 2.0, "love": 2.0, "impressed": 2.0,
    "breakout": 2.0, "gains": 1.8, "healthy": 1.5, "solid": 1.5, "progress": 1.2, "nicely": 1.3,
    "upside": 1.8, "best": 1.8, "buy": 1.0, "buying": 1.0, "support": 0.6, "support.": 0.6,
    "delivering": 1.5, "moon": 1.5, "massive": 1.0, "huge": 1.0, "win": 1.5, "winning": 1.5,
    "🚀": 1.5, "🔥": 1.0, "📈": 1.5, "💎": 1.0,
    # negative
    "bearish": -2.5, "dumping": -2.5, "weak": -1.8, "terrible": -2.5, "worried": -1.8, "bad": -1.8,
    "ugly": -2.0, "failed": -2.0, "sold": -1.5, "sell": -1.2, "selling": -1.3, "risky": -1.5,
    "crash": -2.5, "crashing": -2.5, "scam": -3.0, "rug": -3.0, "awful": -2.5, "fear": -1.8,
    "sellers": -1.0, "loss": -1.8, "losing": -1.8, "dead": -2.0, "fraud": -3.0, "panic": -2.0,
    "📉": -1.5, "💀": -1.5, "🩸": -1.5,
}
_NEGATORS = frozenset({"not", "no", "never", "isn't", "wasn't", "don't", "doesn't", "won't", "cant", "can't"})
_BOOST = {"very": 1.3, "really": 1.25, "extremely": 1.5, "insanely": 1.5, "super": 1.3, "so": 1.15}

_SHILL: Tuple[Tuple["re.Pattern[str]", float], ...] = tuple((re.compile(p, re.I), w) for p, w in (
    (r"\b\d{2,4}x\b", 0.35), (r"\bguaranteed?\b", 0.30), (r"\bdm me\b", 0.30), (r"\bairdrop\b", 0.25),
    (r"\bt\.me/|join (?:our |the )?(?:telegram|discord)", 0.35),
    (r"don'?t miss|last chance|get in (?:now|early)", 0.25),
    (r"free money|passive income|easy gains", 0.30), (r"to the moon|moonshot", 0.15),
))


def score_sentiment(text: str) -> float:
    """Lexicon sentiment in [-1, 1] with negation, intensifiers and emoji."""
    toks = _TOKEN.findall(text.lower())
    total = 0.0
    for i, tok in enumerate(toks):
        v = _LEX.get(tok)
        if v is None:
            continue
        window = toks[max(0, i - 3):i]
        if any(w in _NEGATORS for w in window):
            v = -0.74 * v
        for w in window:
            v *= _BOOST.get(w, 1.0)
        total += v
    return total / math.sqrt(total * total + 10.0)


def shill_score(text: str) -> float:
    s = sum(w for rx, w in _SHILL if rx.search(text))
    if sum(text.count(ch) for ch in "🚀🔥💎") >= 2:
        s += 0.20
    if len(_URL.findall(text)) >= 2:
        s += 0.15
    letters = [c for c in text if c.isalpha()]
    if len(letters) > 12 and sum(c.isupper() for c in letters) / len(letters) > 0.5:
        s += 0.10
    return min(1.0, s)


# MinHash + LSH (near-duplicate detection in O(n))
_P = (1 << 61) - 1
_HRNG = random.Random(0xA790905)
_PERMS = [(_HRNG.randrange(1, _P), _HRNG.randrange(0, _P)) for _ in range(24)]
_BANDS, _ROWS = 8, 3


def _shingles(text: str) -> frozenset:
    toks = _WORD.findall(_MENTION.sub(" ", _URL.sub(" ", text.lower())))
    if len(toks) < 4:
        return frozenset()
    grams = toks + [f"{a} {b}" for a, b in zip(toks, toks[1:])]
    return frozenset(zlib.crc32(g.encode()) for g in grams)


def _minhash(sh: frozenset) -> Optional[Tuple[int, ...]]:
    if not sh:
        return None
    return tuple(min((a * h + b) % _P for h in sh) for a, b in _PERMS)


@dataclass(eq=False)
class Post:
    id: str
    ts: float
    author: str                  # salted pseudonym — raw handles are never stored
    text: str                    # PII-masked
    topics: Tuple[str, ...]
    sentiment: float
    shingles: frozenset
    sig: Optional[Tuple[int, ...]]
    env: Dict[str, float]
    truth: Optional[str] = None  # only populated by the simulator / benchmarks
    # propagation state
    lo: float = 0.0
    hi: float = 1.0
    dead: bool = False
    cred: float = 0.0
    prior: Optional[float] = None
    reasons: List[str] = field(default_factory=list)
    static_hits: Dict[str, bool] = field(default_factory=dict)


def _dig(d: Any, *keys: str, default: Any = None) -> Any:
    if not isinstance(d, Mapping):
        return default
    for k in keys:
        if k in d and d[k] is not None:
            return d[k]
    return default


def _to_epoch(v: Any) -> Optional[float]:
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, str):
        try:
            return _dt.datetime.fromisoformat(v.replace("Z", "+00:00")).timestamp()
        except ValueError:
            try:
                return _dt.datetime.strptime(v, "%a %b %d %H:%M:%S %z %Y").timestamp()
            except ValueError:
                return None
    return None


def normalize(raw: Mapping[str, Any], red: Redactor, salt: bytes) -> Optional[Post]:
    """Raw feed record (flat, v1-style or v2-style) -> sanitized Post. Returns None if unusable."""
    text = _dig(raw, "text", "full_text")
    pid = _dig(raw, "id", "id_str")
    if not isinstance(text, str) or pid is None:
        return None
    user = _dig(raw, "user", "author", default={}) or {}
    handle = _dig(user, "id", "id_str", "screen_name", "username") or _dig(raw, "author_id") or "anon"
    author = hashlib.blake2b(f"{handle}".encode(), key=salt[:32], digest_size=6).hexdigest()
    ts = _to_epoch(_dig(raw, "created_at", "ts", "timestamp")) or time.time()
    age = _dig(user, "account_age_days")
    if age is None:
        created = _to_epoch(_dig(user, "created_at"))
        age = max(0.0, (ts - created) / 86400.0) if created else 365.0
    metrics = _dig(raw, "public_metrics", default=raw)
    likes = int(_dig(metrics, "like_count", "favorite_count", "likes", default=0))
    reposts = int(_dig(metrics, "retweet_count", "repost_count", "reposts", default=0))
    replies = int(_dig(metrics, "reply_count", "replies", default=0))
    followers = int(_dig(user, "followers_count", "followers", default=0))

    shill = shill_score(text)
    clean = red.mask(text)
    topics = tuple(dict.fromkeys(t.upper() for t in _TOPIC.findall(clean)))
    sent = score_sentiment(clean)
    letters = [c for c in clean if c.isalpha()]
    env: Dict[str, float] = {
        "followers": followers, "account_age_days": float(age), "likes": likes, "reposts": reposts,
        "replies": replies, "engagement": likes + reposts + replies,
        "verified": 1.0 if _dig(user, "verified", default=False) else 0.0,
        "sentiment": sent, "abs_sent": abs(sent), "shill_score": shill,
        "url_count": len(_URL.findall(clean)), "mention_count": len(_MENTION.findall(clean)),
        "hashtag_count": len(topics), "text_len": len(clean),
        "caps_ratio": (sum(c.isupper() for c in letters) / len(letters)) if letters else 0.0,
        "cluster_size": 1, "dup_cluster": 1, "dup_rank": 0, "cluster_dead_frac": 0.0,
        "author_posts": 1, "author_dead": 0,
    }
    sh = _shingles(clean)
    return Post(id=str(pid), ts=ts, author=author, text=clean, topics=topics, sentiment=sent,
                shingles=sh, sig=_minhash(sh), env=env, truth=raw.get("_truth"))


# ════════════════════════════════════════════════════════════════════════════
# 4. CONSTRAINT / FORBID PROTOCOL  (bounds propagation to fixpoint)
# ════════════════════════════════════════════════════════════════════════════

DEFAULT_RULES: List[Dict[str, str]] = [
    {"name": "fresh_sock",         "when": "account_age_days < 3 and followers < 25",                 "effect": "forbid"},
    {"name": "shill_lexicon",      "when": "shill_score >= 0.6",                                      "effect": "forbid"},
    {"name": "copypasta_echo",     "when": "dup_cluster >= 4 and dup_rank >= 1",                      "effect": "forbid"},
    {"name": "copypasta_seed",     "when": "dup_cluster >= 4 and dup_rank == 0",                      "effect": "cap:0.25"},
    {"name": "spam_cadence",       "when": "author_posts >= 6",                                       "effect": "cap:0.2"},
    {"name": "engagement_anomaly", "when": "reposts > 25 * (likes + 1) and followers < 200",          "effect": "cap:0.15"},
    {"name": "young_account",      "when": "account_age_days < 14",                                   "effect": "cap:0.5"},
    {"name": "tainted_cluster",    "when": "cluster_size >= 3 and cluster_dead_frac >= 0.5",          "effect": "forbid"},
    {"name": "tainted_author",     "when": "author_dead >= 2",                                        "effect": "forbid"},
    {"name": "verified_floor",     "when": "verified and shill_score < 0.3",                          "effect": "floor:0.6"},
]
DEFAULT_PRIOR = ("min(1, log(1 + followers) / 10) * clip(account_age_days / 365 + 0.25, 0, 1) "
                 "* (1 - 0.6 * shill_score)")
DEFAULT_CONVICTION = "tanh(abs(clean_net) * sqrt(mass) / 3) * (1 - 0.5 * noise_ratio)"


@dataclass
class Rule:
    name: str
    expr: SafeExpr
    kind: str          # forbid | cap | floor
    bound: float
    static: bool       # depends on no cross-post context -> evaluated once per post

    @classmethod
    def from_dict(cls, d: Mapping[str, str]) -> "Rule":
        name, when, effect = d.get("name"), d.get("when"), str(d.get("effect", "forbid"))
        if not name or not when:
            raise RuleError("rule needs 'name' and 'when'")
        kind, _, arg = effect.partition(":")
        if kind not in ("forbid", "cap", "floor"):
            raise RuleError(f"{name}: unknown effect '{effect}'")
        bound = 0.0
        if kind != "forbid":
            try:
                bound = float(arg)
            except ValueError:
                raise RuleError(f"{name}: '{kind}' needs a numeric bound, e.g. cap:0.3") from None
            if not 0.0 <= bound <= 1.0:
                raise RuleError(f"{name}: bound must be in [0, 1]")
        expr = SafeExpr(when, BASE_VARS | CONTEXT_VARS)
        return cls(name, expr, kind, bound, static=not (expr.uses & CONTEXT_VARS))


@dataclass
class PropagationReport:
    total: int = 0
    pruned: int = 0
    capped: int = 0
    rounds: int = 0
    clusters: int = 0
    by_rule: Counter = field(default_factory=Counter)


class Propagator:
    """
    Domain per post: credibility interval [lo, hi] ⊆ [0, 1], initially [0, 1].
    Rules narrow it:  forbid -> {0};  cap:x -> hi=min(hi,x);  floor:x -> lo=max(lo,x).
    Context (duplicate clusters, per-author counts, taint fractions) is recomputed from the
    surviving set every round; iteration stops at a fixpoint. Because domains only shrink,
    termination is guaranteed (and bounded by `max_rounds`).
    """

    def __init__(self, rules: Sequence[Mapping[str, str]] = DEFAULT_RULES, prior: str = DEFAULT_PRIOR,
                 *, max_rounds: int = 8, sim_threshold: float = 0.6) -> None:
        self.rules = [Rule.from_dict(r) for r in rules]
        self.prior = SafeExpr(prior, BASE_VARS)
        self.max_rounds, self.sim_threshold = max_rounds, sim_threshold

    # -- near-duplicate clusters (LSH candidates, exact Jaccard verification) --
    def _cluster(self, posts: List[Post]) -> List[List[Post]]:
        parent = list(range(len(posts)))

        def find(i: int) -> int:
            while parent[i] != i:
                parent[i] = parent[parent[i]]
                i = parent[i]
            return i

        buckets: Dict[Tuple[int, Tuple[int, ...]], List[int]] = defaultdict(list)
        for i, p in enumerate(posts):
            if p.sig:
                for b in range(_BANDS):
                    buckets[(b, p.sig[b * _ROWS:(b + 1) * _ROWS])].append(i)
        for idxs in buckets.values():
            head = idxs[0]
            for j in idxs[1:]:
                rh, rj = find(head), find(j)
                if rh != rj:
                    a, b = posts[head].shingles, posts[j].shingles
                    if len(a & b) / len(a | b) >= self.sim_threshold:
                        parent[rj] = rh
        groups: Dict[int, List[Post]] = defaultdict(list)
        for i, p in enumerate(posts):
            groups[find(i)].append(p)
        return list(groups.values())  # members already in ts order (posts sorted)

    @staticmethod
    def _apply(p: Post, r: Rule) -> bool:
        if r.kind == "forbid":
            p.dead, p.lo, p.hi = True, 0.0, 0.0
            p.reasons.append(r.name)
            return True
        if r.kind == "cap" and r.bound < p.hi:
            p.hi = r.bound
            p.reasons.append(r.name)
            return True
        if r.kind == "floor" and r.bound > p.lo:
            p.lo = r.bound
            return True
        return False

    def run(self, posts: List[Post]) -> PropagationReport:
        posts.sort(key=lambda p: p.ts)
        for p in posts:
            p.lo, p.hi, p.dead, p.cred, p.reasons = 0.0, 1.0, False, 0.0, []
        clusters = self._cluster(posts)
        by_author: Dict[str, List[Post]] = defaultdict(list)
        for p in posts:
            by_author[p.author].append(p)

        rounds, changed = 0, True
        while changed and rounds < self.max_rounds:
            changed, rounds = False, rounds + 1
            for members in clusters:                      # refresh context from survivors
                size = len(members)
                live = [m for m in members if not m.dead]
                frac = (size - len(live)) / size
                for rank, m in enumerate(live):
                    e = m.env
                    e["cluster_size"], e["dup_cluster"], e["dup_rank"], e["cluster_dead_frac"] = size, len(live), rank, frac
            for plist in by_author.values():
                live_n = sum(1 for m in plist if not m.dead)
                for m in plist:
                    m.env["author_posts"], m.env["author_dead"] = live_n, len(plist) - live_n
            for p in posts:
                if p.dead:
                    continue
                for r in self.rules:
                    if r.static:
                        if rounds > 1:
                            continue
                        hit = p.static_hits.get(r.name)
                        if hit is None:
                            hit = p.static_hits[r.name] = bool(r.expr(p.env))
                    else:
                        hit = bool(r.expr(p.env))
                    if hit and self._apply(p, r):
                        changed = True
                    if p.dead:
                        break

        rep = PropagationReport(total=len(posts), rounds=rounds, clusters=sum(1 for c in clusters if len(c) > 1))
        for p in posts:
            if p.dead:
                rep.pruned += 1
                rep.by_rule[p.reasons[-1]] += 1
                continue
            if p.prior is None:
                p.prior = max(0.0, min(1.0, float(self.prior(p.env))))
            if p.lo > p.hi:
                p.lo = p.hi
            p.cred = min(p.hi, max(p.lo, p.prior))
            rep.capped += p.hi < 1.0
        return rep


# ════════════════════════════════════════════════════════════════════════════
# 5. SIGNAL BUILDER  (what survives propagation determines where value shifts)
# ════════════════════════════════════════════════════════════════════════════

@dataclass
class Signal:
    topic: str
    direction: str       # BULL | BEAR | FLAT
    conviction: float    # [0, 1]
    clean_net: float     # credibility-weighted sentiment of survivors
    raw_net: float       # naive sentiment of everything the crowd "said"
    divergence: float    # raw_net - clean_net  (manipulation pressure)
    momentum: float      # clean_net - EMA(previous clean_net)
    noise_ratio: float   # share of posts forbidden
    mass: float          # total surviving credibility
    n_raw: int
    n_clean: int
    manipulated: bool

    def as_dict(self) -> Dict[str, Any]:
        return {k: (round(v, 4) if isinstance(v, float) else v) for k, v in asdict(self).items()}


class SignalBuilder:
    def __init__(self, conviction: str = DEFAULT_CONVICTION, *, threshold: float = 0.15, alpha: float = 0.3,
                 min_clean: int = 3, min_raw: int = 5) -> None:
        self.conviction = SafeExpr(conviction, SIGNAL_VARS)
        self.threshold, self.alpha, self.min_clean, self.min_raw = threshold, alpha, min_clean, min_raw
        self._ema: Dict[str, float] = {}

    def build(self, posts: Iterable[Post]) -> List[Signal]:
        by_topic: Dict[str, List[Post]] = defaultdict(list)
        for p in posts:
            for t in p.topics:
                by_topic[t].append(p)
        out: List[Signal] = []
        for topic, ps in by_topic.items():
            if len(ps) < self.min_raw:
                continue
            live = [p for p in ps if p.cred > 0.0]
            raw = sum(p.sentiment for p in ps) / len(ps)
            mass = sum(p.cred for p in live)
            clean = sum(p.cred * p.sentiment for p in live) / mass if mass > 0 else 0.0
            noise = 1.0 - len(live) / len(ps)
            prev = self._ema.get(topic)
            mom = 0.0 if prev is None else clean - prev
            self._ema[topic] = clean if prev is None else prev + self.alpha * (clean - prev)
            div = raw - clean
            conv = float(self.conviction({"clean_net": clean, "raw_net": raw, "divergence": div, "mass": mass,
                                          "noise_ratio": noise, "momentum": mom, "n_clean": len(live),
                                          "n_raw": len(ps)}))
            direction = "FLAT"
            if len(live) >= self.min_clean:
                direction = "BULL" if clean > self.threshold else "BEAR" if clean < -self.threshold else "FLAT"
            out.append(Signal(topic, direction, max(0.0, min(1.0, conv)), clean, raw, div, mom, noise, mass,
                              len(ps), len(live), manipulated=(noise >= 0.30 and abs(div) >= 0.20)))
        out.sort(key=lambda s: s.conviction, reverse=True)
        return out


# ════════════════════════════════════════════════════════════════════════════
# 6. ASYNC STREAM CONSUMER + ENGINE
# ════════════════════════════════════════════════════════════════════════════

class Atropos:
    def __init__(self, rules: Sequence[Mapping[str, str]] = DEFAULT_RULES, *, prior: str = DEFAULT_PRIOR,
                 conviction: str = DEFAULT_CONVICTION, window_seconds: float = 300.0, max_window: int = 20_000,
                 redactor: Optional[Redactor] = None) -> None:
        self.red = redactor or Redactor()
        self.salt = secrets.token_bytes(32)           # pseudonym salt: per-process, never persisted
        self.propagator = Propagator(rules, prior)
        self.builder = SignalBuilder(conviction)
        self.window_seconds, self.max_window = window_seconds, max_window
        self.window: Deque[Post] = deque()
        self._ids: set = set()

    def process(self, chunk: Iterable[Mapping[str, Any]]) -> Tuple[PropagationReport, List[Signal]]:
        for raw in chunk:
            try:
                p = normalize(raw, self.red, self.salt)
            except (TypeError, ValueError) as exc:
                log.warning("dropped malformed record: %s", exc)
                continue
            if p and p.id not in self._ids:
                self._ids.add(p.id)
                self.window.append(p)
        if self.window:
            horizon = max(p.ts for p in self.window) - self.window_seconds
            while self.window and (self.window[0].ts < horizon or len(self.window) > self.max_window):
                self._ids.discard(self.window.popleft().id)
        posts = list(self.window)
        report = self.propagator.run(posts)
        return report, self.builder.build(posts)

    async def run(self, source: AsyncIterator[List[Mapping[str, Any]]],
                  on_result: Callable[[int, PropagationReport, List[Signal], float], None],
                  queue_size: int = 64) -> None:
        """Bounded-queue pipeline: the producer awaits network I/O while CPU work runs in a worker thread."""
        q: "asyncio.Queue[Optional[List[Mapping[str, Any]]]]" = asyncio.Queue(maxsize=queue_size)

        async def produce() -> None:
            try:
                async for chunk in source:
                    await q.put(chunk)
            finally:
                await q.put(None)

        prod = asyncio.create_task(produce())
        loop, i = asyncio.get_running_loop(), 0
        try:
            while (chunk := await q.get()) is not None:
                t0 = time.perf_counter()
                report, signals = await loop.run_in_executor(None, self.process, chunk)
                i += 1
                on_result(i, report, signals, (time.perf_counter() - t0) * 1000.0)
            await prod
        finally:
            prod.cancel()


def parse_payload(body: bytes) -> List[Mapping[str, Any]]:
    """Accepts a JSON array, {"data": [...], "includes": {"users": [...]}} (v2-style) or NDJSON."""
    text = body.decode("utf-8", errors="replace").strip()
    try:
        obj = json.loads(text)
    except json.JSONDecodeError:
        obj = [json.loads(line) for line in text.splitlines() if line.strip()]
    if isinstance(obj, dict) and isinstance(obj.get("data"), list):
        users = {u.get("id"): u for u in (obj.get("includes") or {}).get("users", [])}
        return [{**d, "user": users.get(d.get("author_id"), {})} for d in obj["data"]]
    return obj if isinstance(obj, list) else [obj]


class HTTPPollSource:
    """Polls a JSON/NDJSON endpoint through SecureTransport (placeholders resolved late)."""

    def __init__(self, transport: SecureTransport, url: str, headers: Optional[Mapping[str, str]] = None,
                 interval: float = 5.0, max_batches: Optional[int] = None) -> None:
        self.t, self.url, self.headers = transport, url, dict(headers or {})
        self.interval, self.max_batches = interval, max_batches

    def __aiter__(self) -> AsyncIterator[List[Mapping[str, Any]]]:
        return self._gen()

    async def _gen(self) -> AsyncIterator[List[Mapping[str, Any]]]:
        n = 0
        while self.max_batches is None or n < self.max_batches:
            try:
                yield parse_payload(await self.t.request("GET", self.url, self.headers))
            except (TransportError, ValueError) as exc:
                log.warning("poll failed: %s", exc)
            n += 1
            await asyncio.sleep(self.interval)


# ════════════════════════════════════════════════════════════════════════════
# 7. SIMULATOR  (mock X/Twitter-shaped feed with hidden ground truth)
# ════════════════════════════════════════════════════════════════════════════

_OPEN = ["", "", "ok so", "honestly", "update:", "quick thought,", "just saw that", "ngl", "so far", "personally"]
_POS = ["{t} looks strong today", "really impressed with the {t} update", "{t} breakout looks real",
        "love what the {t} team shipped", "{t} volume is healthy and the trend is good",
        "bullish on {t} after this earnings call", "{t} holding support nicely, good sign"]
_NEG = ["{t} is dumping and sellers are in control", "worried about {t}, weak volume and bad news",
        "{t} looks terrible after that filing", "sold my {t}, the trend is bearish",
        "{t} failed support, this is ugly", "not buying this {t} bounce, risky"]
_NEU = ["watching {t} closely, no position yet", "reading the {t} filing now",
        "{t} volume about average today", "anyone have data on {t} flows?"]
_DETAIL = ["the order book is thin", "funding rates flipped overnight", "my cousin works nearby and says nothing changed",
           "volume spiked around lunch", "the chart on the four hour looks different", "options flow was odd yesterday",
           "supply chain notes were interesting", "the CEO interview felt rehearsed", "liquidity dried up after the open",
           "competitors announced something similar", "the quarterly numbers are due friday", "retail seems distracted",
           "whales moved coins last night", "analyst downgrade came out early", "the dev update was short",
           "regulators have been quiet lately", "social volume is up a lot", "the spread keeps widening",
           "pre-market looked sleepy", "the community call was packed", "insiders have not sold anything",
           "price action felt choppy", "the roadmap slipped a quarter", "rumors are everywhere today"]
_CLOSE = ["", "", "", "thoughts?", "not advice", "will see tomorrow", "been following this for months",
          "curious what others think", "let's see how it plays out"]
_PUMP = ["🚀🚀 {t} is going to 100x guaranteed!! don't miss the airdrop join t.me/novagems {x}",
         "{t} to the moon 🚀 last chance to get in early, dm me for the gem list {x}",
         "free money alert {t} 🚀🔥 100x easy, join our telegram t.me/gems {x}",
         "{t} bullish bullish 🚀 guaranteed gains, passive income, airdrop live {x}"]
_COUNTER = ["{t} is the best buy right now, huge upside, strong strong 🚀 {x}",
            "everyone is loading {t} 🚀🔥 massive breakout incoming, get in early {x}"]


class MockXStream:
    """
    Three tickers, one hidden story each:
      $NOVA  organic crowd mildly negative; bot swarm pumps it           (pump & dump)
      $ORBT  organic crowd flips bullish -> bearish mid-stream; bots mask (hype trap)
      $KITE  quiet, mildly positive                                       (control)
    """
    TOPICS = ("$NOVA", "$ORBT", "$KITE")

    def __init__(self, seed: int = 7, batches: int = 12, per_batch: int = 60, bot_share: float = 0.38,
                 step: float = 30.0, delay: float = 0.0) -> None:
        self.r = random.Random(seed)
        self.batches, self.per_batch, self.bot_share, self.step, self.delay = batches, per_batch, bot_share, step, delay
        self._profiles: Dict[str, Tuple[int, float, bool]] = {}
        self._t0 = 1_760_000_000.0

    def __aiter__(self) -> AsyncIterator[List[Mapping[str, Any]]]:
        return self._gen()

    async def _gen(self) -> AsyncIterator[List[Mapping[str, Any]]]:
        for b in range(self.batches):
            yield self.batch(b)
            if self.delay:
                await asyncio.sleep(self.delay)

    def _profile(self, handle: str, bot: bool) -> Tuple[int, float, bool]:
        if handle not in self._profiles:
            r = self.r
            if bot:
                old = r.random() < 0.25     # a quarter of the swarm is aged to dodge naive filters
                self._profiles[handle] = (int(r.uniform(0, 300 if old else 40)),
                                          r.uniform(20, 120) if old else r.uniform(0, 6), False)
            else:
                self._profiles[handle] = (int(r.lognormvariate(5.8, 1.5)), r.uniform(60, 3500), r.random() < 0.03)
        return self._profiles[handle]

    def _bias(self, topic: str, b: int) -> float:
        if topic == "$ORBT":
            return 0.55 if b < self.batches / 2 else -0.65
        return -0.25 if topic == "$NOVA" else 0.10

    def _organic(self, topic: str, b: int) -> str:
        r = self.r
        u = r.random()
        pool = _NEU if u < 0.2 else (_POS if r.random() < (1 + self._bias(topic, b)) / 2 else _NEG)
        core = r.choice(pool).format(t=topic)
        mid = ", ".join(r.sample(_DETAIL, 2))
        return " ".join(x for x in (r.choice(_OPEN), core, mid, r.choice(_CLOSE)) if x)

    def batch(self, b: int) -> List[Mapping[str, Any]]:
        r, base = self.r, self._t0 + b * self.step
        n_bot = round(self.per_batch * self.bot_share)
        out: List[Dict[str, Any]] = []
        for i in range(self.per_batch):
            bot = i < n_bot
            ts = base + r.uniform(0, self.step)
            if bot:
                handle = f"x{r.randrange(70):03d}"
                target_orbt = b >= self.batches / 2 and r.random() < 0.4
                topic = "$ORBT" if target_orbt else "$NOVA"
                text = r.choice(_COUNTER if target_orbt else _PUMP).format(t=topic, x="%04x" % r.randrange(65536))
                likes, reposts, replies = r.randrange(4), int(r.expovariate(1 / 60)), 0
            else:
                handle = f"u{r.randrange(400):04d}"
                topic = r.choices(self.TOPICS, weights=(0.3, 0.4, 0.3))[0]
                text = self._organic(topic, b)
                likes, reposts, replies = int(r.expovariate(1 / 8)), int(r.expovariate(1 / 3)), int(r.expovariate(1 / 2))
            fol, age, ver = self._profile(handle, bot)
            out.append({"id": f"p{b}-{i}", "text": text, "created_at": ts,
                        "user": {"id": handle, "followers_count": fol, "account_age_days": age, "verified": ver},
                        "public_metrics": {"like_count": likes, "retweet_count": reposts, "reply_count": replies},
                        "_truth": "bot" if bot else "organic"})
        r.shuffle(out)
        return out


# ════════════════════════════════════════════════════════════════════════════
# 8. CLI, RENDERING, BENCHMARK, SELF-TEST
# ════════════════════════════════════════════════════════════════════════════

def render(i: int, rep: PropagationReport, sigs: List[Signal], ms: float, color: bool) -> str:
    c = (lambda code, s: f"\x1b[{code}m{s}\x1b[0m") if color else (lambda code, s: s)
    head = (f"── batch {i:02d} │ window {rep.total} │ forbidden {rep.pruned} ({rep.pruned / max(rep.total, 1):.0%})"
            f" │ capped {rep.capped} │ rounds {rep.rounds} │ {ms:.1f} ms")
    lines = [c("2", head),
             c("2", f"  {'TOPIC':<8}{'DIR':<6}{'CONV':>6}{'CLEAN':>8}{'RAW':>8}{'Δ':>8}{'MOM':>8}{'NOISE':>7}  FLAGS")]
    for s in sigs:
        col = "38;5;203" if s.direction == "BEAR" else "38;5;110" if s.direction == "BULL" else "2"
        row = (f"  {s.topic:<8}{s.direction:<6}{s.conviction:>6.2f}{s.clean_net:>+8.2f}{s.raw_net:>+8.2f}"
               f"{s.divergence:>+8.2f}{s.momentum:>+8.2f}{s.noise_ratio:>7.0%}  ")
        lines.append(c(col, row) + (c("1;38;5;196", "MANIPULATED") if s.manipulated else ""))
    return "\n".join(lines)


def run_benchmark(n: int = 20_000, seed: int = 7, per_batch: int = 200) -> Dict[str, Any]:
    stream = MockXStream(seed=seed, batches=max(1, n // per_batch), per_batch=per_batch)
    eng = Atropos(window_seconds=300.0)
    state: Dict[str, Tuple[str, bool, float]] = {}
    lat: List[float] = []
    err_raw: List[float] = []
    err_clean: List[float] = []
    t_all = time.perf_counter()
    for b in range(stream.batches):
        chunk = stream.batch(b)
        t0 = time.perf_counter()
        rep, sigs = eng.process(chunk)
        lat.append((time.perf_counter() - t0) * 1000.0)
        for p in eng.window:
            state[p.id] = (p.truth or "?", p.dead, p.cred)
        if b >= 3:  # warm-up: let the window fill
            for s in sigs:
                org = [p.sentiment for p in eng.window if p.truth == "organic" and s.topic in p.topics]
                if len(org) >= 10:
                    truth = sum(org) / len(org)
                    err_raw.append(abs(s.raw_net - truth))
                    err_clean.append(abs(s.clean_net - truth))
    elapsed = time.perf_counter() - t_all
    tp = sum(1 for t, d, _ in state.values() if t == "bot" and d)
    fn = sum(1 for t, d, _ in state.values() if t == "bot" and not d)
    fp = sum(1 for t, d, _ in state.values() if t == "organic" and d)
    tn = sum(1 for t, d, _ in state.values() if t == "organic" and not d)
    bots = sum(1 for t, _, _ in state.values() if t == "bot")
    mass_all = sum(c for _, _, c in state.values()) or 1.0
    mass_bot = sum(c for t, _, c in state.values() if t == "bot")
    lat_sorted = sorted(lat)
    return {
        "posts": len(state), "batches": stream.batches, "seed": seed, "python": sys.version.split()[0],
        "throughput_posts_per_s": round(len(state) / elapsed),
        "batch_latency_ms_p50": round(statistics.median(lat), 1),
        "batch_latency_ms_p99": round(lat_sorted[min(len(lat) - 1, int(len(lat) * 0.99))], 1),
        "bot_precision": round(tp / max(tp + fp, 1), 4), "bot_recall": round(tp / max(tp + fn, 1), 4),
        "organic_false_positive_rate": round(fp / max(fp + tn, 1), 4),
        "bot_share_of_posts": round(bots / len(state), 4),
        "bot_share_of_credibility_mass": round(mass_bot / mass_all, 4),
        "sentiment_mae_raw": round(statistics.fmean(err_raw), 4),
        "sentiment_mae_clean": round(statistics.fmean(err_clean), 4),
    }


def selftest() -> int:
    ok = True

    def check(label: str, cond: bool) -> None:
        nonlocal ok
        ok &= cond
        print(f"  [{'ok' if cond else 'FAIL'}] {label}")

    print("SafeExpr — adversarial inputs must be rejected at parse time:")
    for bad in ("__import__('os').system('id')", "().__class__.__bases__", "[x for x in (1,2)]", "lambda: 1",
                "followers.real", "followers[0]", "'a' + 'b'", "(y := 3)", "open('/etc/passwd')",
                "max(*[1,2])", "min(1, key=abs)", "followers if", "f'{followers}'", "unknown_var + 1",
                "exp.__call__(1)", "1 if 2 else __builtins__"):
        try:
            SafeExpr(bad, BASE_VARS)
            check(f"rejected {bad!r}", False)
        except RuleError:
            check(f"rejected {bad!r}", True)
    e = SafeExpr("clip(followers / 0 + 2 ** 3, 0, 5) + (1 if verified else 0)", BASE_VARS)
    check("div-by-zero is neutral, clip/ternary work", e({"followers": 10, "verified": 1.0}) == 6)
    try:
        SafeExpr("9 ** 99", BASE_VARS)({})
        check("pow bound enforced", False)
    except RuleError:
        check("pow bound enforced", True)
    print("Redactor:")
    red = Redactor()
    red.register("X_TOKEN", "tok_abcdef123456")
    m = red.mask("mail me bob@example.com tok_abcdef123456 https://x.io/a?access_token=zzz call 415-555-0199 sk-ABCDEFGHIJKLMNOP1234")
    check("PII/secrets masked", not any(s in m for s in ("bob@", "tok_abc", "zzz", "555-0199", "sk-ABC")))
    vault = Vault(red)
    vault.put("X_TOKEN", "tok_abcdef123456")
    check("vault injects placeholders", vault.inject("Bearer {{secret:X_TOKEN}}") == "Bearer tok_abcdef123456")
    check("vault repr hides values", "tok_abc" not in repr(vault))
    print("Propagation:")
    rep, sigs = Atropos().process(MockXStream(batches=1, per_batch=120).batch(0))
    check("fixpoint reached", 1 <= rep.rounds <= 8 and rep.pruned > 0)
    return 0 if ok else 1


def load_config(path: Optional[str]) -> Dict[str, Any]:
    if not path:
        return {}
    with open(path, "r", encoding="utf-8") as fh:
        cfg = json.load(fh)
    if not isinstance(cfg, dict):
        raise SystemExit("config must be a JSON object")
    return cfg


def main(argv: Optional[Sequence[str]] = None) -> int:
    ap = argparse.ArgumentParser(prog="atropos", description="It watches the panic. It cuts the noise.")
    ap.add_argument("--demo", action="store_true", help="run on the built-in simulated feed (default)")
    ap.add_argument("--bench", nargs="?", const=20_000, type=int, metavar="N", help="synthetic benchmark on N posts")
    ap.add_argument("--selftest", action="store_true", help="run security/invariant checks")
    ap.add_argument("--url", help="poll a JSON/NDJSON endpoint; may contain {{secret:NAME}}")
    ap.add_argument("--header", action="append", default=[], help='"Name: value" (placeholders allowed)')
    ap.add_argument("--allow-host", action="append", help="restrict outbound hosts (repeatable)")
    ap.add_argument("--interval", type=float, default=5.0)
    ap.add_argument("--rules", help="JSON config: {rules, prior, conviction, window_seconds}")
    ap.add_argument("--window", type=float, help="window length in seconds")
    ap.add_argument("--batches", type=int, default=12)
    ap.add_argument("--per-batch", type=int, default=60)
    ap.add_argument("--delay", type=float, default=0.0, help="seconds between simulated batches")
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--json", action="store_true", help="emit NDJSON signals")
    ap.add_argument("--explain", action="store_true", help="print pruning reasons at exit")
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args(argv)

    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    red = Redactor()
    handler = logging.StreamHandler(sys.stderr)
    handler.addFilter(MaskingFilter(red))
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    log.addHandler(handler)
    log.setLevel(logging.INFO if a.verbose else logging.WARNING)

    if a.selftest:
        return selftest()
    if a.bench is not None:
        print(json.dumps(run_benchmark(a.bench, a.seed), indent=2))
        return 0

    cfg = load_config(a.rules)
    eng = Atropos(cfg.get("rules", DEFAULT_RULES), prior=cfg.get("prior", DEFAULT_PRIOR),
                  conviction=cfg.get("conviction", DEFAULT_CONVICTION),
                  window_seconds=a.window or cfg.get("window_seconds", 300.0), redactor=red)
    if a.url:
        headers = {k.strip(): v.strip() for k, _, v in (h.partition(":") for h in a.header)}
        source: Any = HTTPPollSource(SecureTransport(Vault(red), red, allow_hosts=a.allow_host), a.url, headers, a.interval)
    else:
        source = MockXStream(seed=a.seed, batches=a.batches, per_batch=a.per_batch, delay=a.delay)

    color = sys.stdout.isatty() and not a.json
    reasons: Counter = Counter()

    def on_result(i: int, rep: PropagationReport, sigs: List[Signal], ms: float) -> None:
        reasons.update(rep.by_rule)
        if a.json:
            print(json.dumps({"batch": i, "ms": round(ms, 2), "pruned": rep.pruned, "total": rep.total,
                              "signals": [s.as_dict() for s in sigs]}), flush=True)
        else:
            print(render(i, rep, sigs, ms, color), flush=True)

    try:
        asyncio.run(eng.run(source, on_result))
    except KeyboardInterrupt:
        pass
    if a.explain and not a.json:
        print("\nforbidden-by-rule (cumulative over batches):")
        for name, k in reasons.most_common():
            print(f"  {name:<20}{k:>7}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
